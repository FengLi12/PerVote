import datetime
import logging
import os
from os.path import join
from typing import List
from numpy import size
from numpy import where
# Libraries for graphs
# import community
import networkx as nx
import math
# Libraries for matrix computations
import numpy as np
import pandas as pd
from pandas import concat
from scipy.stats import pearsonr
# Import functions from HWVoteRank module



import matplotlib.pyplot as plt


DATA_DIR = "./Data"
OUT_DIR = "./Output"
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
def mean_value(a):
    n = len(a)
    sum_mean = 0
    for i in a:
        sum_mean += i
    return sum_mean / n

def PVOTE(G, l):

    rank = []

    nodes = list(nx.nodes(G))

    degree_li = nx.degree(G, weight="weight")
    d_max = max([i[1] for i in degree_li])

    degree_dic = {}
    for i in degree_li:
        degree_dic[i[0]] = i[1]

    node_ability = {}
    for item in degree_li:
        node_ability[item[0]] = 1  # ln(x)

    degree_values = degree_dic.values()
    weaky = 1 / mean_value(degree_values)
    # node's score
    node_score = get_node_score2(G, nodes, node_ability, degree_dic, rank)

    node_type = pd.DataFrame()
    node_type['nodes'] = nodes
    node_type.set_index(["nodes"], inplace=True)
    node_type['degree'] = [0] * node_type.shape[0]
    node_type['lable'] = [5] * node_type.shape[0]

    node_type_all = pd.read_csv('./degree_lable.csv')
    node_type_all.set_index(["gene"], inplace=True)
    for ii in list(node_type.index.values):
        node_type.loc[ii, 'degree'] = degree_dic[ii]
        node_type.loc[ii, 'lable'] = node_type_all.loc[ii, 'lable']

    node_mean_TypeDegree = node_type.groupby('lable')['degree'].mean()

    for ii in list(node_type.index.values):
        if node_type.loc[ii, 'lable'] == 0:
            node_type.loc[ii, 'degree'] = node_mean_TypeDegree[0]
        if node_type.loc[ii, 'lable'] == 1:
            node_type.loc[ii, 'degree'] = node_mean_TypeDegree[1]
        if node_type.loc[ii, 'lable'] == 2:
            node_type.loc[ii, 'degree'] = node_mean_TypeDegree[2]

    for i in range(l):
        max_score_node, score = max(node_score.items(), key=lambda x: x[1])
        rank.append((max_score_node, score))
        node_ability[max_score_node] = 0

        node_score.pop(max_score_node)

        cur_nbrs = list(nx.neighbors(G, rank[-1][0]))


        next_cur_neigh = []
        next_cur_neigh_1 = []
        for nbr in cur_nbrs:
            nnbr = nx.neighbors(G, nbr)
            # next_cur_neigh_1.extend(nnbr)
            for node_nnbr in nnbr:
                if node_type.loc[node_nnbr, 'lable'] == node_type.loc[nbr, 'lable'] and node_type.loc[
                    max_score_node, 'lable'] == node_type.loc[nbr, 'lable']:
                    next_cur_neigh.append(node_nnbr)

            if node_type.loc[max_score_node, 'lable'] == node_type.loc[nbr, 'lable']:

                next_cur_neigh_1.extend(nx.neighbors(G, nbr))

                node_ability[nbr] = 0.5 * node_ability[nbr]
                if node_ability[nbr] < 0:
                    node_ability[nbr] = 0

        next_cur_neighs = list(set(next_cur_neigh))
        for ih in rank:
            if ih[0] in next_cur_neighs:
                next_cur_neighs.remove(ih[0])
        for i in cur_nbrs:
            if i in next_cur_neighs:
                next_cur_neighs.remove(i)

        for nnbr in next_cur_neighs:


            node_ability[nnbr] = math.sqrt(0.5) * node_ability[nnbr]
            if node_ability[nnbr] < 0:
                node_ability[nnbr] = 0

        next_cur_neighs_1 = list(set(next_cur_neigh_1))
        for jh in rank:
            if jh[0] in next_cur_neighs_1:
                next_cur_neighs_1.remove(jh[0])
        for j in cur_nbrs:
            if j in next_cur_neighs_1:
                next_cur_neighs_1.remove(j)


        H = []
        H.extend(cur_nbrs)
        H.extend(next_cur_neighs_1)
        for nbr in next_cur_neighs:
            nbrs = nx.neighbors(G, nbr)
            H.extend(nbrs)

        H = list(set(H))
        for ih in rank:
            if ih[0] in H:
                H.remove(ih[0])
        new_nodeScore = get_node_score2(G, H, node_ability, degree_dic, rank)
        node_score.update(new_nodeScore)



    return rank

def get_node_score2(G, nodesNeedcalcu, node_ability, degree_dic, rank):

    weight = get_weight(G, degree_dic, rank)
    node_score = {}
    for node in nodesNeedcalcu:
        sum2 = 0
        neighbors = list(nx.neighbors(G, node))
        for nbr in neighbors:
            sum2 += node_ability[nbr] * (weight[(nbr, node)] + (G[nbr][node]['weight']) *len(neighbors) / degree_dic[node])#Outputother5中的机制 和OutputOther1少了前面的0.5
        node_score[node] = math.sqrt(len(neighbors) * sum2)
    return node_score

def get_weight(G, degree_dic, rank):
    weight = {}
    nodes = nx.nodes(G)
    rank_list = [i[0] for i in rank]
    for node in nodes:
        sum1 = 0
        neighbors = list(nx.neighbors(G, node))
        neighbors_common_rank = list(set(neighbors) & set(rank_list))
        if len(neighbors_common_rank) != 0:
            for nc in neighbors_common_rank:
                weight[(node, nc)] = 0
        neighbours_without_rank = list(set(neighbors) - set(rank_list))
        if len(neighbours_without_rank) != 0:
            for nbr in neighbours_without_rank:
                sum1 += degree_dic[nbr]
            for neigh in neighbours_without_rank:
                weight[(node, neigh)] = degree_dic[neigh] / sum1
        else:
            for neigh in neighbors:
                weight[(node, neigh)] = 0
    return weight

def configure_logging(logger):

    logger_handler = logging.StreamHandler()
    logger_handler.setLevel(logging.INFO)

    # create formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    # add formatter to ch
    logger_handler.setFormatter(formatter)

    # add ch to logger
    logger.addHandler(logger_handler)

def build_graph_from_edge_list(cancer_network: pd.DataFrame, is_weighted=False) -> nx.Graph:

    if is_weighted:
        try:
            G = nx.from_pandas_edgelist(cancer_network, source="reg", target="tar", edge_attr=['weight'])
        except:
            raise ValueError("Dataframe does not contain a column containing edge weights")
    else:
        G = nx.from_pandas_edgelist(cancer_network, source="reg", target="tar")
    logger.info("Number of nodes: {0}, and number of edges: {1}".format(len(G.nodes), len(G.edges)))
    logger.info("Graph edge weights: {0}".format(G.size(weight='weight')))
    return G


def compute_pearson_correlation(cancer_network: pd.DataFrame, cancer_data: pd.DataFrame) -> pd.DataFrame:
    correlation_coeffs = []
    correlation_pvals = []

    x = cancer_network.reg.values.tolist()
    y = cancer_network.tar.values.tolist()

    for x_i, y_i in zip(x, y):
        corr, pval = pearsonr(cancer_data.loc[:, x_i], cancer_data.loc[:, y_i])
        correlation_coeffs.append(corr)
        correlation_pvals.append(pval)

    cancer_network["correlation"] = pd.Series(correlation_coeffs)
    cancer_network["pval"] = pd.Series(correlation_pvals)
    cancer_network["weight"] = cancer_network["correlation"].abs()
    return cancer_network


if __name__ == "__main__":
    configure_logging(logger)

    start_time = datetime.datetime.now()
    logger.info("Reading cancer gene expression data")
    cancer_df = pd.read_csv(join(DATA_DIR, 'CancerDriver', 'Cancer', 'cancer_data.csv'))
    logger.info("Reading cancer node")
    cancer_node = pd.read_csv(join(DATA_DIR, 'CancerDriver', 'Cancer', 'nodeList.csv'))
    logger.info("Reading cancer network edge list")
    cancer_network = pd.read_csv(join(DATA_DIR, 'CancerDriver', 'Cancer', 'cancer_network_LIONESS.csv'))
    cancer_network = pd.DataFrame(cancer_network)
    drivers = cancer_node.iloc[:, [0]]
    drivers =pd.DataFrame(drivers, columns=['node'])
    if not os.path.exists(join(OUT_DIR, 'CancerDriver', 'Cancer')):
        os.makedirs(join(OUT_DIR, 'CancerDriver', 'Cancer'))
    for i in range(2,n): #n为样本的数量
        net = cancer_network.iloc[:,[0,1,i]].copy()
        net = pd.DataFrame(net)
        net.iloc[:,[2]] = net.iloc[:,[2]].abs()
        aaa = net.columns[2]
        net = net[net[aaa] > net[aaa].mean()]
        net = net.iloc[:,[0,1]].copy()
        net.to_csv(join(OUT_DIR, 'CancerDriver', 'Cancer', f'ne{i}t.csv'))
        net2 = pd.read_csv(join(OUT_DIR, 'CancerDriver', 'Cancer', f'ne{i}t.csv'))
        net3= pd.DataFrame(net2)
        net4 = net3.iloc[:, [1, 2]].copy()
        net5 = compute_pearson_correlation(net4, cancer_df)
        G = build_graph_from_edge_list(net5, is_weighted=True)
        F = PVOTE(G, 300, 1, 1)
        FF = pd.DataFrame(F, columns=['node', 'importance'])
        critical_nodes = FF
        temp = cancer_node
        temp = pd.DataFrame(temp, columns=['node'])
        merg = pd.merge(left=temp,right=critical_nodes,how="left",left_on="node",right_on="node")
        merg = pd.DataFrame(merg)
        merg.to_csv(join(OUT_DIR, 'CancerDriver', 'Cancer', 'merg.csv'))
        drivers = pd.merge(left=drivers,right=merg,how="left",left_on="node",right_on="node")
        drivers = pd.DataFrame(drivers)
        drivers.rename(columns={drivers.columns[i - 1]: aaa}, inplace=True)
        drivers.to_csv(join(OUT_DIR, 'CancerDriver', 'Cancer', 'drivers.csv'))
    drivers = drivers.fillna(0)
    drivers.to_csv(join(OUT_DIR, 'CancerDriver', 'Cancer', 'drivers2.csv'))

